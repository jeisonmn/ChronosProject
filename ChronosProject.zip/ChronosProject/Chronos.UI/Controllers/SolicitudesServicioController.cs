﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using AutoMapper;
using Chronos.DAL.Interfaces;
using Chronos.DAL.Metodos;

namespace Chronos.UI.Controllers
{
    public class SolicitudesServicioController : Controller
    {
        // GET: SolicitudesServicio
        ISolicitudesServicio mSolicitud;
        public SolicitudesServicioController()
        {
            mSolicitud = new MSolicitudesServicio();
        }
        //
        // GET: /Cliente/
        public ActionResult Index()
        {
            var solicitudServicio = mSolicitud.ListarSolicitudesServicios();
            var solicitudServicioMostrar = Mapper.Map<List<Models.SolicitudesServicio>>(solicitudServicio);
            return View(solicitudServicioMostrar);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Models.SolicitudesServicio solicitud)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View();
                }
                var solicitudInsertar = Mapper.Map<DATA.SolicitudesServicio>(solicitud);
                mSolicitud.InsertarSolicitudesServicio(solicitudInsertar);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ActionResult Details(int id)
        {
            var solicitud = mSolicitud.BuscarSolicitudesServicio(id);
            var solicitudMostrar = Mapper.Map<Models.SolicitudesServicio>(solicitud);
            return View(solicitudMostrar);
        }

        public ActionResult Edit(int id)
        {
            var solicitud = mSolicitud.BuscarSolicitudesServicio(id);
            var solicitudMostrar = Mapper.Map<Models.SolicitudesServicio>(solicitud);
            return View(solicitudMostrar);
        }

        [HttpPost]
        public ActionResult Edit(Models.SolicitudesServicio solicitud)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View();
                }
                var solicitudEditar = Mapper.Map<DATA.SolicitudesServicio>(solicitud);
                mSolicitud.ActualizarSolicitudesServicio(solicitudEditar);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                mSolicitud.EliminarSolicitudesServicio(id);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}