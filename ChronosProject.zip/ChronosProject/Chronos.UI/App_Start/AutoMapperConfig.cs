﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using AutoMapper;

namespace Chronos.UI
{
    public static class AutoMapperConfig
    {
        public static void Configure()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.CreateMap<Models.SolicitudesServicio, DATA.SolicitudesServicio>();
                cfg.CreateMap<DATA.SolicitudesServicio, Models.SolicitudesServicio>();
            });
        }
    }
}