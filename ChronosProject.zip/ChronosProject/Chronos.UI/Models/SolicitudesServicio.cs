﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chronos.UI.Models
{
    public class SolicitudesServicio
    {
        public int IdSolicitud { get; set; }

        public int Cliente { get; set; }

        public long NumeroCuenta { get; set; }

        public string Solicitante { get; set; }

        public string Aprobado { get; set; }

        public DateTime FechaEmision { get; set; }

        public int TipoEntrega { get; set; }

        public string DireccionEntrega { get; set; }

        public string DetalleServicio { get; set; }

        public int ReproduccionesTotales { get; set; }

        public double CostoTotal { get; set; }

        public int EstadoActual { get; set; }

        public int DepartamentoActual { get; set; }

        public int? MaquinaAsignada { get; set; }

        public int? UsuarioAsignado { get; set; }

        public bool Activo { get; set; }

    }
}