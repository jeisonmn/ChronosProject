﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Chronos.DAL.Interfaces;
using Chronos.DATA;
using ServiceStack.OrmLite;

namespace Chronos.DAL.Metodos
{
    public class MSolicitudesServicio : MDataBase, ISolicitudesServicio
    {

        public void ActualizarSolicitudesServicio(SolicitudesServicio solicitud)
        {
            _db.Update(solicitud);
        }

        public SolicitudesServicio BuscarSolicitudesServicio(int idSolicitudesServicio)
        {
            return _db.Select<SolicitudesServicio>(x => x.IdSolicitud == idSolicitudesServicio).FirstOrDefault();
        }


        public void EliminarSolicitudesServicio(int idSolicitudesServicio)
        {
            _db.Delete<SolicitudesServicio>(x => x.IdSolicitud == idSolicitudesServicio);
        }

        public void InsertarSolicitudesServicio(SolicitudesServicio solicitud)
        {
            _db.Insert(solicitud);
        }

        public List<SolicitudesServicio> ListarSolicitudesServicios()
        {
            return _db.Select<SolicitudesServicio>();
        }
    }
}
