﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Chronos.DATA;

namespace Chronos.DAL.Interfaces
{
    public interface ISolicitudesServicio
    {
        List<SolicitudesServicio> ListarSolicitudesServicios();
        SolicitudesServicio BuscarSolicitudesServicio(int idSolicitudesServicio);
        void InsertarSolicitudesServicio(SolicitudesServicio solicitud);
        void ActualizarSolicitudesServicio(SolicitudesServicio solicitud);
        void EliminarSolicitudesServicio(int idSolicitudesServicio);
    }
}
