﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lec04.DATA;
using Lec04.DAL.Interfaces;
using ServiceStack.OrmLite;

namespace Lec04.DAL.Metodos
{
    public class MUsuario : MBase, IUsuario
    {
        public Usuario Login(string username, string password)
        {
            return _db.Select<Usuario>(x => x.Username == username && x.Password == password).FirstOrDefault();
        }
    }
}
