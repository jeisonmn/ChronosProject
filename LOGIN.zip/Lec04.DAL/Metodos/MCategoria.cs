﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lec04.DATA;
using Lec04.DAL;
using Lec04.DAL.Interfaces;
using ServiceStack.OrmLite;
using System.Data;

namespace Lec04.DAL.Metodos
{
    public class MCategoria : MBase, ICategoria
    {
        public List<Categoria> ListarCategorias()
        {
            return _db.Select<Categoria>();
        }
    }
}
