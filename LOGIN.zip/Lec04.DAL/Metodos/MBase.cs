﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lec04.DATA;
using Lec04.DAL;
using Lec04.DAL.Interfaces;
using ServiceStack.OrmLite;
using System.Data;

namespace Lec04.DAL.Metodos
{
    public class MBase
    {
        public OrmLiteConnectionFactory _conexion;
        public IDbConnection _db;

        public MBase()
        {
            _conexion = new OrmLiteConnectionFactory(
                BD.Default.conexion,
                SqlServerDialect.Provider
                );

            _db = _conexion.Open();

        }
    }
}
