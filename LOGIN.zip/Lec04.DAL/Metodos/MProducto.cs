﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lec04.DATA;
using Lec04.DAL.Interfaces;
using ServiceStack.OrmLite;
using System.Data;

namespace Lec04.DAL.Metodos
{
    public class MProducto : MBase, IProducto
    {
        

        public void ActualizarProducto(Producto producto)
        {
            _db.Update(producto);
        }

        public Producto BuscarProducto(int idProducto)
        {
            return _db.Select<Producto>(x => x.IdProducto == idProducto).FirstOrDefault();
        }

        public void EliminarProducto(int idProducto)
        {
            _db.Delete<Producto>(x => x.IdProducto == idProducto);
        }

        public void InsertarProducto(Producto producto)
        {
            _db.Insert(producto);
        }

        public List<Producto> ListarPorCategoria(int idCategoria)
        {
            return _db.Select<Producto>(x => x.Categoria == idCategoria);
        }

        public List<Producto> ListarProductos()
        {
            return _db.Select<Producto>();
        }

        public List<ProductoVista> ListarProductosVista()
        {
            //return _db.SqlList<ProductoVista>(string.Format("EXEC sp_ListarProductos {0},{1}",id,nombre));
            return _db.SqlList<ProductoVista>("EXEC sp_ListarProductos");
            
        }
    }
}
