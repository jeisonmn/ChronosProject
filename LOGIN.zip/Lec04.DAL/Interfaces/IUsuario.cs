﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lec04.DATA;



namespace Lec04.DAL.Interfaces
{
    public interface IUsuario
    {
        Usuario Login(string username, string password);
    }
}
