﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lec04.UI.App_Start
{
    public static class AutomapperConfig
    {
        public static void Configure()
        {
            Mapper.Initialize(cfg =>
            {
                //Solo hay un Initialize

                cfg.CreateMap<Models.Producto, DATA.Producto>();
                cfg.CreateMap<DATA.Producto, Models.Producto>();

                //Por cada objeto que se quiera mapear.

                cfg.CreateMap<Models.Categoria, DATA.Categoria>();
                cfg.CreateMap<DATA.Categoria, Models.Categoria>();

                cfg.CreateMap<Models.ProductoVista, DATA.ProductoVista>();
                cfg.CreateMap<DATA.ProductoVista, Models.ProductoVista>();

            }
            );
        }
    }
}