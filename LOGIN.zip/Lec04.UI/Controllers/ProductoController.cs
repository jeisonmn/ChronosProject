﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using Lec04.DAL.Interfaces;
using Lec04.DAL.Metodos;


namespace Lec04.UI.Controllers
{
    public class ProductoController : Controller
    {
        IProducto prod;
        ICategoria cat;

        public ProductoController()
        {
            prod = new MProducto();
            cat = new MCategoria();
        }

        // GET: Producto
        public ActionResult Index()
        {
            var listaProductos = prod.ListarProductosVista();
            var lista = Mapper.Map<List<Models.ProductoVista>>(listaProductos);
            return View(lista);

        }

        public ActionResult Create()
        {
            return View();

        }

        [HttpPost]
        public ActionResult Create(Models.Producto producto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View();
                }
                var productoInsertar = Mapper.Map<DATA.Producto>(producto);
                prod.InsertarProducto(productoInsertar);
                return RedirectToAction("Index");

            }
            catch (Exception)
            {

                throw;

            }

        }


        public ActionResult Details(int id)
        {
            var producto = prod.BuscarProducto(id);
            var productoMostrar = Mapper.Map<Models.Producto>(producto);
            return View(productoMostrar);
        }

        public ActionResult Edit(int id)
        {
            var producto = prod.BuscarProducto(id);
            var productoMostrar = Mapper.Map<Models.Producto>(producto);
            return View(productoMostrar);
        }

        [HttpPost]
        public ActionResult Edit(Models.Producto producto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View();
                }
                var productoActualizar = Mapper.Map<DATA.Producto>(producto);
                prod.ActualizarProducto(productoActualizar);
                return RedirectToAction("Index"); 
            }
            catch (Exception)
            {

                throw;
            }
        }

        public ActionResult Delete(int id)
        {
            prod.EliminarProducto(id);
            return RedirectToAction("Index");

        }

        public ActionResult Carrito()
        {
            var listaProductos = prod.ListarProductos();
            var lista = Mapper.Map<List<Models.Producto>>(listaProductos);

            ViewBag.ddlCategorias = new SelectList(cat.ListarCategorias(), "IdCategoria", "Nombre");

            return View(lista);
        }

        [HttpPost]
        public ActionResult CambiarCategoria()
        {
            var categoria = Request.Form["ddlCategorias"];
            ViewBag.ddlCategorias = new SelectList(cat.ListarCategorias(), "IdCategoria", "Nombre");

            List<Models.Producto> productosListar;
            List<DATA.Producto> productos;


            if(categoria== string.Empty)
            {
                productos = prod.ListarProductos();
                productosListar = Mapper.Map<List<Models.Producto>>(productos);
                return View("Carrito", productosListar);
            }

            var idCategoria = Convert.ToInt32(categoria);
            productos = prod.ListarPorCategoria(idCategoria);
            productosListar = Mapper.Map<List<Models.Producto>>(productos);
            return View("Carrito", productosListar);

        }

        public ActionResult AgregarCarrito (int id)
        {
            var producto = prod.BuscarProducto(id);

            if (Session["carrito"] == null)
            {
                List<DATA.Producto> lista = new List<DATA.Producto>();
                lista.Add(producto);
                Session["carrito"] = lista;
                ViewBag.conteo = string.Format("Cantidad en Carrito: {0}", lista.Count());

            }
            else
            {
                List<DATA.Producto> lista = (List<DATA.Producto>)Session["carrito"];
                lista.Add(producto);
                Session["carrito"] = lista;
                ViewBag.conteo = string.Format("Cantidad en Carrito: {0}", lista.Count());

            }
            var listaProductos = prod.ListarProductos();
            var listaMostrar = Mapper.Map<List<Models.Producto>>(listaProductos);

            ViewBag.ddlCategorias = new SelectList(cat.ListarCategorias(), "IdCategoria", "Nombre");

            return View("Carrito", listaMostrar);

        }





    }
}