﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lec04.DAL.Metodos;
using Lec04.DAL.Interfaces;

namespace Lec04.UI.Controllers
{
    public class UsuarioController : Controller
    {
        IUsuario usu;

        public UsuarioController()
        {
            usu = new MUsuario();
        }

        // GET: Usuario
        public ActionResult Login()
        {
         // return View("Login", "_Layout-Login2");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Models.Usuario usuario)
        {
            var usuarioMostrar = usu.Login(usuario.Username, usuario.Password);

            if (usuarioMostrar == null)
            {
                ViewBag.error = "Usuario o Contraseña Incorrecta";
                return View();
            }
            Session["usuario"] = usuarioMostrar.Username;
            return RedirectToAction("Index", "Producto");

        }
    }
}