﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using UI.Models;

namespace UI.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private CHRONOSDBEntities1 db = new CHRONOSDBEntities1();

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login([Bind(Include = "NombreDeUsuario, Contraseña")] Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                var obj = db.Usuarios.Where(a => a.NombreDeUsuario.Equals(usuario.NombreDeUsuario) && a.Contraseña.Equals(usuario.Contraseña)).FirstOrDefault();
                if (obj != null)
                {
                    Session["Nombre"] = obj.Nombre.ToString();
                    Session["Usuario"] = obj.NombreDeUsuario.ToString();
                    Session["Id"] = obj.IdUsuario.ToString();
                    return RedirectToAction("UserDashBoard");
                }
            }
            return View(usuario);
        }

        public ActionResult UserDashBoard()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
    }
}