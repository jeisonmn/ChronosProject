﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UI.Models;

namespace UI.Controllers
{
    public class HistorialActualizacionesSolicitudesController : Controller
    {
        private CHRONOSDBEntities1 db = new CHRONOSDBEntities1();

        // GET: HistorialActualizacionesSolicitudes
        public ActionResult Index()
        {
            var historialActualizacionesSolicitudes = db.HistorialActualizacionesSolicitudes.Include(h => h.Departamento).Include(h => h.Departamento1).Include(h => h.EstadoSolicitude).Include(h => h.EstadoSolicitude1).Include(h => h.Usuario).Include(h => h.Usuario1).Include(h => h.SolicitudesServicio).Include(h => h.Usuario2);
            return View(historialActualizacionesSolicitudes.ToList());
        }

        // GET: HistorialActualizacionesSolicitudes/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HistorialActualizacionesSolicitude historialActualizacionesSolicitude = db.HistorialActualizacionesSolicitudes.Find(id);
            if (historialActualizacionesSolicitude == null)
            {
                return HttpNotFound();
            }
            return View(historialActualizacionesSolicitude);
        }

        // GET: HistorialActualizacionesSolicitudes/Create
        public ActionResult Create()
        {
            ViewBag.NuevoDepartamento = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1");
            ViewBag.DepartamentoPrevio = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1");
            ViewBag.NuevoEstado = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado");
            ViewBag.EstadoPrevio = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado");
            ViewBag.UsuarioNuevo = new SelectList(db.Usuarios, "IdUsuario", "Nombre");
            ViewBag.UsuarioActualiza = new SelectList(db.Usuarios, "IdUsuario", "Nombre");
            ViewBag.Solicitud = new SelectList(db.SolicitudesServicios, "ID", "DireccionEntrega");
            ViewBag.UsuarioPrevio = new SelectList(db.Usuarios, "IdUsuario", "Nombre");
            return View();
        }

        // POST: HistorialActualizacionesSolicitudes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "IdActualizacion,Solicitud,CambiaDepartamento,DepartamentoPrevio,NuevoDepartamento,CambiaEstado,EstadoPrevio,NuevoEstado,CambiaUsuario,UsuarioPrevio,UsuarioNuevo,FechaCambio,UsuarioActualiza")] HistorialActualizacionesSolicitude historialActualizacionesSolicitude)
        {
            if (ModelState.IsValid)
            {
                db.HistorialActualizacionesSolicitudes.Add(historialActualizacionesSolicitude);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.NuevoDepartamento = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", historialActualizacionesSolicitude.NuevoDepartamento);
            ViewBag.DepartamentoPrevio = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", historialActualizacionesSolicitude.DepartamentoPrevio);
            ViewBag.NuevoEstado = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", historialActualizacionesSolicitude.NuevoEstado);
            ViewBag.EstadoPrevio = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", historialActualizacionesSolicitude.EstadoPrevio);
            ViewBag.UsuarioNuevo = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioNuevo);
            ViewBag.UsuarioActualiza = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioActualiza);
            ViewBag.Solicitud = new SelectList(db.SolicitudesServicios, "ID", "DireccionEntrega", historialActualizacionesSolicitude.Solicitud);
            ViewBag.UsuarioPrevio = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioPrevio);
            return View(historialActualizacionesSolicitude);
        }

        // GET: HistorialActualizacionesSolicitudes/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HistorialActualizacionesSolicitude historialActualizacionesSolicitude = db.HistorialActualizacionesSolicitudes.Find(id);
            if (historialActualizacionesSolicitude == null)
            {
                return HttpNotFound();
            }
            ViewBag.NuevoDepartamento = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", historialActualizacionesSolicitude.NuevoDepartamento);
            ViewBag.DepartamentoPrevio = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", historialActualizacionesSolicitude.DepartamentoPrevio);
            ViewBag.NuevoEstado = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", historialActualizacionesSolicitude.NuevoEstado);
            ViewBag.EstadoPrevio = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", historialActualizacionesSolicitude.EstadoPrevio);
            ViewBag.UsuarioNuevo = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioNuevo);
            ViewBag.UsuarioActualiza = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioActualiza);
            ViewBag.Solicitud = new SelectList(db.SolicitudesServicios, "ID", "DireccionEntrega", historialActualizacionesSolicitude.Solicitud);
            ViewBag.UsuarioPrevio = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioPrevio);
            return View(historialActualizacionesSolicitude);
        }

        // POST: HistorialActualizacionesSolicitudes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "IdActualizacion,Solicitud,CambiaDepartamento,DepartamentoPrevio,NuevoDepartamento,CambiaEstado,EstadoPrevio,NuevoEstado,CambiaUsuario,UsuarioPrevio,UsuarioNuevo,FechaCambio,UsuarioActualiza")] HistorialActualizacionesSolicitude historialActualizacionesSolicitude)
        {
            if (ModelState.IsValid)
            {
                db.Entry(historialActualizacionesSolicitude).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.NuevoDepartamento = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", historialActualizacionesSolicitude.NuevoDepartamento);
            ViewBag.DepartamentoPrevio = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", historialActualizacionesSolicitude.DepartamentoPrevio);
            ViewBag.NuevoEstado = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", historialActualizacionesSolicitude.NuevoEstado);
            ViewBag.EstadoPrevio = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", historialActualizacionesSolicitude.EstadoPrevio);
            ViewBag.UsuarioNuevo = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioNuevo);
            ViewBag.UsuarioActualiza = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioActualiza);
            ViewBag.Solicitud = new SelectList(db.SolicitudesServicios, "ID", "DireccionEntrega", historialActualizacionesSolicitude.Solicitud);
            ViewBag.UsuarioPrevio = new SelectList(db.Usuarios, "IdUsuario", "Nombre", historialActualizacionesSolicitude.UsuarioPrevio);
            return View(historialActualizacionesSolicitude);
        }

        // GET: HistorialActualizacionesSolicitudes/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HistorialActualizacionesSolicitude historialActualizacionesSolicitude = db.HistorialActualizacionesSolicitudes.Find(id);
            if (historialActualizacionesSolicitude == null)
            {
                return HttpNotFound();
            }
            return View(historialActualizacionesSolicitude);
        }

        // POST: HistorialActualizacionesSolicitudes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            HistorialActualizacionesSolicitude historialActualizacionesSolicitude = db.HistorialActualizacionesSolicitudes.Find(id);
            db.HistorialActualizacionesSolicitudes.Remove(historialActualizacionesSolicitude);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
