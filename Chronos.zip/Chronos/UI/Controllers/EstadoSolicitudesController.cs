﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UI.Models;

namespace UI.Controllers
{
    public class EstadoSolicitudesController : Controller
    {
        private CHRONOSDBEntities1 db = new CHRONOSDBEntities1();

        // GET: EstadoSolicitudes
        public ActionResult Index()
        {
            return View(db.EstadoSolicitudes.ToList());
        }

        // GET: EstadoSolicitudes/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EstadoSolicitude estadoSolicitude = db.EstadoSolicitudes.Find(id);
            if (estadoSolicitude == null)
            {
                return HttpNotFound();
            }
            return View(estadoSolicitude);
        }

        // GET: EstadoSolicitudes/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EstadoSolicitudes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "IdEstado,Estado,Activo")] EstadoSolicitude estadoSolicitude)
        {
            if (ModelState.IsValid)
            {
                db.EstadoSolicitudes.Add(estadoSolicitude);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(estadoSolicitude);
        }

        // GET: EstadoSolicitudes/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EstadoSolicitude estadoSolicitude = db.EstadoSolicitudes.Find(id);
            if (estadoSolicitude == null)
            {
                return HttpNotFound();
            }
            return View(estadoSolicitude);
        }

        // POST: EstadoSolicitudes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "IdEstado,Estado,Activo")] EstadoSolicitude estadoSolicitude)
        {
            if (ModelState.IsValid)
            {
                db.Entry(estadoSolicitude).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(estadoSolicitude);
        }

        // GET: EstadoSolicitudes/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EstadoSolicitude estadoSolicitude = db.EstadoSolicitudes.Find(id);
            if (estadoSolicitude == null)
            {
                return HttpNotFound();
            }
            return View(estadoSolicitude);
        }

        // POST: EstadoSolicitudes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EstadoSolicitude estadoSolicitude = db.EstadoSolicitudes.Find(id);
            db.EstadoSolicitudes.Remove(estadoSolicitude);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
