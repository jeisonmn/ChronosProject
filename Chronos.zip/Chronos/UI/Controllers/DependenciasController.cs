﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UI.Models;

namespace UI.Controllers
{
    public class DependenciasController : Controller
    {
        private CHRONOSDBEntities1 db = new CHRONOSDBEntities1();

        // GET: Dependencias
        public ActionResult Index()
        {
            return View(db.Dependencias.ToList());
        }

        // GET: Dependencias/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dependencia dependencia = db.Dependencias.Find(id);
            if (dependencia == null)
            {
                return HttpNotFound();
            }
            return View(dependencia);
        }

        // GET: Dependencias/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Dependencias/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "IdDependencia,Sector_Direcccion_Dependencia,CentroFuncional,Telefono,Activo")] Dependencia dependencia)
        {
            if (ModelState.IsValid)
            {
                db.Dependencias.Add(dependencia);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(dependencia);
        }

        // GET: Dependencias/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dependencia dependencia = db.Dependencias.Find(id);
            if (dependencia == null)
            {
                return HttpNotFound();
            }
            return View(dependencia);
        }

        // POST: Dependencias/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "IdDependencia,Sector_Direcccion_Dependencia,CentroFuncional,Telefono,Activo")] Dependencia dependencia)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dependencia).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(dependencia);
        }

        // GET: Dependencias/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dependencia dependencia = db.Dependencias.Find(id);
            if (dependencia == null)
            {
                return HttpNotFound();
            }
            return View(dependencia);
        }

        // POST: Dependencias/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Dependencia dependencia = db.Dependencias.Find(id);
            db.Dependencias.Remove(dependencia);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
