﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UI.Models;

namespace UI.Controllers
{
    public class SolicitudesServiciosController : Controller
    {
        private CHRONOSDBEntities1 db = new CHRONOSDBEntities1();

        // GET: SolicitudesServicios
        public ActionResult Index()
        {
            var solicitudesServicios = db.SolicitudesServicios.Include(s => s.Departamento).Include(s => s.Dependencia1).Include(s => s.Dependencia2).Include(s => s.EstadoSolicitude).Include(s => s.Maquina).Include(s => s.Solicitante1).Include(s => s.Usuario).Include(s => s.TiposEntrega).Include(s => s.Usuario1);
            return View(solicitudesServicios.ToList());
        }

        // GET: SolicitudesServicios/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SolicitudesServicio solicitudesServicio = db.SolicitudesServicios.Find(id);
            if (solicitudesServicio == null)
            {
                return HttpNotFound();
            }
            return View(solicitudesServicio);
        }

        // GET: SolicitudesServicios/Create
        public ActionResult Create()
        {
            ViewBag.DepartamentoActual = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1");
            ViewBag.Dependencia = new SelectList(db.Dependencias, "IdDependencia", "Sector_Direcccion_Dependencia");
            ViewBag.Dependencia = new SelectList(db.Dependencias, "IdDependencia", "Sector_Direcccion_Dependencia");
            ViewBag.EstadoActual = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado");
            ViewBag.MaquinaAsignada = new SelectList(db.Maquinas, "IdMaquina", "Maquina1");
            ViewBag.Solicitante = new SelectList(db.Solicitantes, "IdSolicitante", "Solicitante1");
            ViewBag.Aprobado = new SelectList(db.Usuarios, "IdUsuario", "Nombre");
            ViewBag.TipoEntrega = new SelectList(db.TiposEntregas, "IdTipoEntrega", "TipoEntrega");
            ViewBag.UsuarioAsignado = new SelectList(db.Usuarios, "IdUsuario", "Nombre");
            return View();
        }

        // POST: SolicitudesServicios/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Solicitud,FechaEmision,Dependencia,NumeroCuenta,Solicitante,Aprobado,TipoEntrega,DireccionEntrega,DetalleServicio,ReproduccionesTotales,CostoTotal,EstadoActual,DepartamentoActual,MaquinaAsignada,UsuarioAsignado,Activo")] SolicitudesServicio solicitudesServicio)
        {
            if (ModelState.IsValid)
            {
                db.SolicitudesServicios.Add(solicitudesServicio);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DepartamentoActual = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", solicitudesServicio.DepartamentoActual);
            ViewBag.Dependencia = new SelectList(db.Dependencias, "IdDependencia", "Sector_Direcccion_Dependencia", solicitudesServicio.Dependencia);
            ViewBag.Dependencia = new SelectList(db.Dependencias, "IdDependencia", "Sector_Direcccion_Dependencia", solicitudesServicio.Dependencia);
            ViewBag.EstadoActual = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", solicitudesServicio.EstadoActual);
            ViewBag.MaquinaAsignada = new SelectList(db.Maquinas, "IdMaquina", "Maquina1", solicitudesServicio.MaquinaAsignada);
            ViewBag.Solicitante = new SelectList(db.Solicitantes, "IdSolicitante", "Solicitante1", solicitudesServicio.Solicitante);
            ViewBag.Aprobado = new SelectList(db.Usuarios, "IdUsuario", "Nombre", solicitudesServicio.Aprobado);
            ViewBag.TipoEntrega = new SelectList(db.TiposEntregas, "IdTipoEntrega", "TipoEntrega", solicitudesServicio.TipoEntrega);
            ViewBag.UsuarioAsignado = new SelectList(db.Usuarios, "IdUsuario", "Nombre", solicitudesServicio.UsuarioAsignado);
            return View(solicitudesServicio);
        }

        // GET: SolicitudesServicios/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SolicitudesServicio solicitudesServicio = db.SolicitudesServicios.Find(id);
            if (solicitudesServicio == null)
            {
                return HttpNotFound();
            }
            ViewBag.DepartamentoActual = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", solicitudesServicio.DepartamentoActual);
            ViewBag.Dependencia = new SelectList(db.Dependencias, "IdDependencia", "Sector_Direcccion_Dependencia", solicitudesServicio.Dependencia);
            ViewBag.Dependencia = new SelectList(db.Dependencias, "IdDependencia", "Sector_Direcccion_Dependencia", solicitudesServicio.Dependencia);
            ViewBag.EstadoActual = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", solicitudesServicio.EstadoActual);
            ViewBag.MaquinaAsignada = new SelectList(db.Maquinas, "IdMaquina", "Maquina1", solicitudesServicio.MaquinaAsignada);
            ViewBag.Solicitante = new SelectList(db.Solicitantes, "IdSolicitante", "Solicitante1", solicitudesServicio.Solicitante);
            ViewBag.Aprobado = new SelectList(db.Usuarios, "IdUsuario", "Nombre", solicitudesServicio.Aprobado);
            ViewBag.TipoEntrega = new SelectList(db.TiposEntregas, "IdTipoEntrega", "TipoEntrega", solicitudesServicio.TipoEntrega);
            ViewBag.UsuarioAsignado = new SelectList(db.Usuarios, "IdUsuario", "Nombre", solicitudesServicio.UsuarioAsignado);
            return View(solicitudesServicio);
        }

        // POST: SolicitudesServicios/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Solicitud,FechaEmision,Dependencia,NumeroCuenta,Solicitante,Aprobado,TipoEntrega,DireccionEntrega,DetalleServicio,ReproduccionesTotales,CostoTotal,EstadoActual,DepartamentoActual,MaquinaAsignada,UsuarioAsignado,Activo")] SolicitudesServicio solicitudesServicio)
        {
            if (ModelState.IsValid)
            {
                db.Entry(solicitudesServicio).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DepartamentoActual = new SelectList(db.Departamentos, "IdDepartamento", "Departamento1", solicitudesServicio.DepartamentoActual);
            ViewBag.Dependencia = new SelectList(db.Dependencias, "IdDependencia", "Sector_Direcccion_Dependencia", solicitudesServicio.Dependencia);
            ViewBag.Dependencia = new SelectList(db.Dependencias, "IdDependencia", "Sector_Direcccion_Dependencia", solicitudesServicio.Dependencia);
            ViewBag.EstadoActual = new SelectList(db.EstadoSolicitudes, "IdEstado", "Estado", solicitudesServicio.EstadoActual);
            ViewBag.MaquinaAsignada = new SelectList(db.Maquinas, "IdMaquina", "Maquina1", solicitudesServicio.MaquinaAsignada);
            ViewBag.Solicitante = new SelectList(db.Solicitantes, "IdSolicitante", "Solicitante1", solicitudesServicio.Solicitante);
            ViewBag.Aprobado = new SelectList(db.Usuarios, "IdUsuario", "Nombre", solicitudesServicio.Aprobado);
            ViewBag.TipoEntrega = new SelectList(db.TiposEntregas, "IdTipoEntrega", "TipoEntrega", solicitudesServicio.TipoEntrega);
            ViewBag.UsuarioAsignado = new SelectList(db.Usuarios, "IdUsuario", "Nombre", solicitudesServicio.UsuarioAsignado);
            return View(solicitudesServicio);
        }

        // GET: SolicitudesServicios/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SolicitudesServicio solicitudesServicio = db.SolicitudesServicios.Find(id);
            if (solicitudesServicio == null)
            {
                return HttpNotFound();
            }
            return View(solicitudesServicio);
        }

        // POST: SolicitudesServicios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            SolicitudesServicio solicitudesServicio = db.SolicitudesServicios.Find(id);
            db.SolicitudesServicios.Remove(solicitudesServicio);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
